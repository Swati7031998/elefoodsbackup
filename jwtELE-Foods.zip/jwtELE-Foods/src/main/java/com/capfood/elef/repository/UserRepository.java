package com.capfood.elef.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capfood.elef.entities.User;

public interface UserRepository extends JpaRepository<User, String>{

	@Query("SELECT user.emailId from User user")
	public List<String> getEmailIdList();
	
	@Query("SELECT user.mobileNumber from User user")
	public List<String> getMobileNumberList();
	
	@Query("SELECT user from User user where user.emailId =:puser")
	public User getByName(@Param(value="puser") String userName);
	
	@Query("SELECT login from User login where login.emailId = :name")
	public List<User> searchByEmailId(@Param(value="name") String emailId);
	
	@Query("SELECT user from User user where user.role='Customer'")
	public List<User> getCustomers();
	
	@Query("SELECT user from User user where user.role='Admin'")
	public List<User> getAdmins();
}
