import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { ResetNowComponent } from './components/reset-password/reset-now.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { UserServiceService } from './services/user-service.service';
import { AuthenticationService } from './authentication.service';
import { AuthguardGuard } from './guards/authguard.guard';
import { AdminGuard } from './guards/admin.guard';
import { JWT_OPTIONS, JwtHelperService } from '@auth0/angular-jwt';
import { HttpInterceptorInterceptor } from './http-interceptor.interceptor';
import { AdminComponent } from './components/admin/admin.component';
import { CustomerComponent } from './components/customer/customer.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignUpComponent,
    ResetNowComponent,
    ResetPasswordComponent,
    AdminComponent,
    CustomerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    UserServiceService,
    AuthenticationService,
    AuthguardGuard,
    AdminGuard,
    { provide: JWT_OPTIONS, useValue: JWT_OPTIONS },
    JwtHelperService,
    { provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
