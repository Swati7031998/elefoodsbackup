export class NewUser{
    username:String;
    password:String;
}