import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { ResetNowComponent } from './components/reset-password/reset-now.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { AdminGuard } from './guards/admin.guard';
import { AuthguardGuard } from './guards/authguard.guard';
import { AdminComponent } from './components/admin/admin.component';
import { CustomerComponent } from './components/customer/customer.component';


const routes: Routes = [
  {path:'', component:LoginComponent},
{path:'login', component:LoginComponent},
{
  path:'admin',
  component:AdminComponent,
  canActivate:[AdminGuard]
},
{
  path:'customer',
  component:CustomerComponent,
  canActivate:[AuthguardGuard]
},
{path:'sign-up',component:SignUpComponent},
{path:'reset-password',component:ResetNowComponent},
{path:'reset-password1',component:ResetPasswordComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
