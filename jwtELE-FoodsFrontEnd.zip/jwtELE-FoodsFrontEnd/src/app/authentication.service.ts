import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private jwtHelper:JwtHelperService,private http:HttpClient,private _route:Router) { }

  url="http://localhost:8094";
  
  decodedToken:any=undefined;
  isTokenValid()
  {
    
    if(localStorage.getItem("token")!=undefined && !this.jwtHelper.isTokenExpired(localStorage.getItem("token")))
    {
      this.decodedToken=this.jwtHelper.decodeToken(localStorage.getItem("token"));
      return true;
    }

    if(localStorage.getItem("token"))
    {
      localStorage.removeItem("token");
    }


    this._route.navigate(["login"]);
    return false;
  }

  setToken(token:string)
  {
    localStorage.setItem("token",token);
  }

  getToken()
  {
    return localStorage.getItem("token");
  }

  authenticate(credentials)
  {
    this.http.post(this.url+"/authenticate",credentials).subscribe(data=>{
      let somedata:any=data;
      if(data)
      {
        this.setToken(somedata.jwt);
        let decoded=this.jwtHelper.decodeToken(somedata.jwt);
        if(decoded && decoded.isAdmin)
        {
          this._route.navigate(["admin"]);
        }else
        {
          this._route.navigate(["customer"]);
        }
     
      }
    },(error)=>{
      alert("Invalid Email Id or password");
      
    })
  }

  
public isAdmin()
{
  if(this.isTokenValid())
  {
    let decoded:any=this.jwtHelper.decodeToken(localStorage.getItem("token"));
    if(decoded.isAdmin)
    {
      return true;
    }
    this._route.navigate(["customer"]);
    return false;
  }
  return false;
}

  
public isUser()
{
  if(this.isTokenValid())
  {
    let decoded:any=this.jwtHelper.decodeToken(localStorage.getItem("token"));
    if(decoded.isAdmin)
    {
      this._route.navigate(["admin"]);
      return false;
    }
    return true;
  }
  return false;
}

public logout()
{
  if(localStorage.getItem("token"))
  {
    localStorage.removeItem("token");
    this._route.navigate(["/"]);
  }
}

public isLoggedIn()
{

  // if(localStorage.getItem("token")!=undefined)
  // {
  //   return false;
  // }
  if(localStorage.getItem("token")==undefined)
  {
    localStorage.removeItem("token");
  }
  return localStorage.getItem("token")!=undefined && !this.jwtHelper.isTokenExpired(localStorage.getItem("token"));
}

public getUserid()
{
  console.log("In Side User Id");
  // if(this.isUser())
  // {
    
    let decoded=this.jwtHelper.decodeToken(localStorage.getItem("token"));
    return decoded.userId;
  //}
  return undefined;
}

}
