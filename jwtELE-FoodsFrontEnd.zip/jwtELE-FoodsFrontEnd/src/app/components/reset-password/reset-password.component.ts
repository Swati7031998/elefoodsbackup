import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomValidator } from 'src/custom-validator';
import { ForgotPassword } from 'src/app/models/ForgotPassword.model';
import { Router } from '@angular/router';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {
  submitted: boolean;
  resetForm: FormGroup;
  message:String;
  changePassword:ForgotPassword={
    emailId:undefined,
    security_question:undefined,
    security_answer:undefined,
    newPassword:undefined,
    reEnterNewPassword:undefined
  }
  errormsg: String;
  constructor(private formBuilder:FormBuilder,private router:Router,private userService:UserServiceService) { }

  ngOnInit() {
    if (!(localStorage.emailId)) {
      this.router.navigate(['']);
    }
    this.resetForm=this.formBuilder.group({
      reEnterPassword:['',Validators.required],
      password: ['', Validators.compose([
        Validators.required,
        Validators.minLength(8),
        CustomValidator.patternValidator(/\d/, { hasNumber: true }),
        CustomValidator.patternValidator(/[A-Z]/, { hasCapitalCase: true }),
        CustomValidator.patternValidator(/[a-z]/, { hasSmallCase: true }),
        CustomValidator.patternValidator(/[?=.*/'":;<>~|[\]{}\\!@#$%^&()]/, { hasSpecialCharacters: true })
      ])]
    })
  }
  verify(){
    this.submitted=true;
    if(this.resetForm.invalid){
      return;
    }
    else{
      this.changePassword.newPassword=this.resetForm.controls.password.value;
      this.changePassword.reEnterNewPassword=this.resetForm.controls.reEnterPassword.value;
      this.changePassword.emailId=localStorage.emailId;
      this.userService.resetPassword(this.changePassword).subscribe(data=>
        {
          this.message=data;
          alert(this.message);
          localStorage.removeItem("emailId");
          this.router.navigate(['']);
        },err=>{
          this.errormsg=err.error;
      alert(this.errormsg);
        }
      )
      
    }
  }

}
