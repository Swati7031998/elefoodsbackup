import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/authentication.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  email: any;
  constructor(private auth: AuthenticationService) {
      this.email = this.auth.getUserid();
   }

  ngOnInit() {
  }

}
