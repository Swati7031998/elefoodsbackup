import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserServiceService } from 'src/app/services/user-service.service';
import { NewUser } from 'src/app/models/NewUser.models';
import { AuthenticationService } from 'src/app/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted: boolean= false;
  invalidLogin:boolean = false;
  msg:String;
  errormsg:String;
  user:NewUser={
    username:undefined,
    password:undefined
  };
  constructor(private formBuilder:FormBuilder,private router:Router,private userService:UserServiceService, private authservice:AuthenticationService) { }

  ngOnInit() {
    if(localStorage.email||localStorage.emailId||localStorage.password){
      localStorage.removeItem("email");
      localStorage.removeItem("emailId");
      localStorage.removeItem("password");
    }
    this.loginForm = this.formBuilder.group({
      emailId:['',[Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  verifyLogin(){
    this.submitted = true;
    if(this.loginForm.invalid){
      return;
    }
    let email = this.loginForm.controls.emailId.value;
    let password = this.loginForm.controls.password.value;
  
   this.user.username=email;
   this.user.password=password;
   this.authservice.authenticate(this.user);
    // this.userService.userLogin(this.user).subscribe(data => {
    //   this.msg= data;
    //   localStorage.email=email;
    //   localStorage.password=password;
    //   if(this.msg=="Admin")
    // {
    //   this.router.navigate([]);
    // }
    // else if(this.msg=="Customer")
    // {
    //   this.router.navigate([]);
    // } 
    // },
    //   err => {
    //     this.errormsg=err.error;
    //     this.invalidLogin = true;
    //     alert(this.errormsg);
    //   });
    
  } 
}

