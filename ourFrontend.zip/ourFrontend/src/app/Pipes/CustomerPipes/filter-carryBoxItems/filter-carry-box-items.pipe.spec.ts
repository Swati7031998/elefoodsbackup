import { FilterCarryBoxItemsPipe } from './filter-carry-box-items.pipe';

describe('FilterCarryBoxItemsPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterCarryBoxItemsPipe();
    expect(pipe).toBeTruthy();
  });
});
