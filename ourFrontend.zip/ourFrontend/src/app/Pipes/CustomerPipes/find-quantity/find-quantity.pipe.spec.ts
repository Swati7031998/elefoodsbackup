import { FindQuantityPipe } from './find-quantity.pipe';

describe('FindQuantityPipe', () => {
  it('create an instance', () => {
    const pipe = new FindQuantityPipe();
    expect(pipe).toBeTruthy();
  });
});
