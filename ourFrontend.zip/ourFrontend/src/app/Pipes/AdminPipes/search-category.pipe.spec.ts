import { SearchCategoryPipe } from './search-category.pipe';

describe('SearchCategoryPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchCategoryPipe();
    expect(pipe).toBeTruthy();
  });
});
