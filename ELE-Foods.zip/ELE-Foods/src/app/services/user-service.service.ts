import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError} from 'rxjs';
import { catchError } from 'rxjs/operators';
import { NewUser } from '../models/NewUser.models';
import { SignUp } from '../models/SignUp.model';
import { ForgotPassword } from '../models/ForgotPassword.model';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private http:HttpClient) { }
  baseUrl: string = "http://localhost:8094";
   
  userLogin(user:NewUser){
    return this.http.post<any>(this.baseUrl + "/authenticate",user,{responseType:'text' as 'json'}).pipe(catchError(this.handleError));
   }

   signUp(sign_up:SignUp){
     return this.http.post<any>(this.baseUrl+"/signup",sign_up,{responseType:"text" as "json"}).pipe(catchError(this.handleError));
   }
   forgotPassword(forgotPassword:ForgotPassword){
     return this.http.post<any>(this.baseUrl+"/forgotPassword",forgotPassword,{responseType:"text" as "json"}).pipe(catchError(this.handleError));
   }
   resetPassword(changePassword:ForgotPassword){
    return this.http.post<any>(this.baseUrl+"/changePassword",changePassword,{responseType:"text" as "json"}).pipe(catchError(this.handleError));
  }
  private handleError(errorResponse: HttpErrorResponse) {
    return throwError(errorResponse);
  }
}
