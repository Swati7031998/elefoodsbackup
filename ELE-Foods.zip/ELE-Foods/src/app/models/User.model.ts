export class User{
    customerName:String;
    emailId:String;
    password:String;
    security_question:String;
    security_answer:String;
    mobileNumber:String;
}