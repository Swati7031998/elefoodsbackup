import { CustomValidator2 } from './custom-validator2';

describe('CustomValidator2', () => {
  it('should create an instance', () => {
    expect(new CustomValidator2()).toBeTruthy();
  });
});
