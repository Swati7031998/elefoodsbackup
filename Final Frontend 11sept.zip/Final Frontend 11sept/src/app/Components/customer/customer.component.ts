import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoggingService } from '../../Models/LoggingService';


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})

export class CustomerComponent implements OnInit {

  filter: string = ""
  searchText: string = "";
  showMenu: boolean = false
  userLoggedIn: boolean = false
  showLogo: boolean = true

  constructor(private router: Router, private logger: LoggingService) { }
  ngOnInit() {
    this.filter = ""
    this.searchText = ""
    this.expandHeader()
    this.router.navigate(["customer"])
    this.toggleLogo()

    //To check whether the user is logged in or not
    if (localStorage.email != ""&& localStorage.email) {
      this.userLoggedIn = true
    }

  }


  //To reset the animations of logo every 30seconds once
  toggleLogo() {
    this.showLogo = false
    setTimeout(() => {
      this.showLogo = true
    }, 1000);
    setTimeout(() => {
      this.toggleLogo()
    }, 30000);
  }


  //To navigate to items page with a filter
  goToItems() {
    this.compressHeader()
    this.router.navigate(["/customer/items/category/" + this.filter])
    this.logger.logStatus("Navigating to "+this.filter+" items page!!");
  }


  //To navigate to items page with by searching
  goToSearchItems() {
    if (this.searchText != "") {
      this.compressHeader()
      this.router.navigate(["/customer/items/search/" + this.searchText])
      this.logger.logStatus("Searching for '"+this.searchText+"' items !!");
    }
  }


  //To reduce the height of the header and remove the menu buttons when navigating to 
  //Items poage, orders page,carry box etc.,
  compressHeader() {
    if (screen.availWidth > 800) {
      document.getElementById("header-bottom1").style.display = "none";
    }
    else {
      document.getElementById("header-bottom2").style.display = "none";
    }

    document.getElementById("header").style.height = "10vh";
    document.getElementById("header").style.opacity = "1";
  }


  //To increase the height of the header and add the menu buttons when navigated to Home page
  expandHeader() {
    if (screen.availWidth > 800) {
      document.getElementById("header-bottom1").style.display = "flex";
    }
    else {
      document.getElementById("header-bottom2").style.display = "flex";
    }

    if (screen.availWidth > 600) {
      document.getElementById("header").style.height = "20vh";
    }
    else {
      document.getElementById("header").style.height = "15vh";
    }

    document.getElementById("header").style.opacity = "1";
  }

  //To navigate to home page
  goToHome() {
    this.expandHeader()
    this.router.navigate(["customer"])
    this.logger.logStatus("Navigating to Home page!!");
  }


  //To navigate to My Orders Page
  goToMyOrders() {
    this.closeMenu()
    this.compressHeader()
    this.router.navigate(["customer/myOrders"])
    this.logger.logStatus("Navigating to My Orders Page!!");
  }


  //To navigate to carrybox page
  goToMyCarryBox() {
    this.closeMenu()
    this.compressHeader()
    this.router.navigate(["customer/myCarryBox"])
    this.logger.logStatus("Navigating to Carry Box Page!!");
  }


  //To remove the header during placing an order
  removeHeader() {
    document.getElementById("header").style.height = "0vh";
    document.getElementById("header").style.opacity = "0";
  }


  //To navigate to items page with filter of categories
  setFilter(filter: string) {
    this.filter = filter
    this.goToItems()
    this.logger.logStatus("Navigating to "+filter+" Items page!!");
  }

  //To show the user menu options
  openMenu() {
    this.showMenu = true
    document.getElementById("menuExtension").style.height = "30vh"
    document.getElementById("menuExtension").style.width = "30vh"
  }


  //To close the user menu options
  closeMenu() {
    this.showMenu = false
    document.getElementById("menuExtension").style.height = "5vh"
    document.getElementById("menuExtension").style.width = "5vh"
  }


  //To navigate to login page
  login() {
    this.router.navigate(['authenticate'])
    this.logger.logStatus("Navigating to Login Page!!");
  }


  //To logout and navigate to home page
  logout() {
    this.closeMenu()
    this.userLoggedIn = false
    localStorage.email = "";
    this.router.navigate([''])
    this.logger.logStatus("User Logged out!!");
  }

}

