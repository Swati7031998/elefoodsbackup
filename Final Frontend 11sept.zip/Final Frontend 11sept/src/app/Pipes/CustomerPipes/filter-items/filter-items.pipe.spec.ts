import { FilterItemsPipe } from './filter-items.pipe';

describe('FilterItemsPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterItemsPipe();
    expect(pipe).toBeTruthy();
  });
});
