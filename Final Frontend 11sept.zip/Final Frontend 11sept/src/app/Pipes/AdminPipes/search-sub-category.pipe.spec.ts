import { SearchSubCategoryPipe } from './search-sub-category.pipe';

describe('SearchSubCategoryPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchSubCategoryPipe();
    expect(pipe).toBeTruthy();
  });
});
