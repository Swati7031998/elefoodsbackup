import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Item } from '../../Models/Item';
import { SubCategory } from '../../Models/subCategory';
import { Order } from '../../Models/Order';
import { CarryBox } from '../../Models/CarryBox';
import { Address } from '../../Models/Address';

@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {

  constructor(private http:HttpClient) { }


  /* Method:getABranchItems
	 * Type: GetMapping
	 * Description: Called from customer home page to view all the existing items in his location
	 * @param int: branchId
	 * @return List<Item>: a List of all the existing items in the given branch
	 * @throws ResourceNotFoundException : It is raised when no data is found with the given request
	*/
  getABranchItems(branchId:number){
    return this.http.get<Item[]>("http://localhost:8094/customer/getABranchItems/"+branchId);
  }



  /* Method:searchItems
	 * Type: GetMapping
	 * Description: Called from home page to search for desired items or categories
	 * @param int: branchId
	 * @param String: searchText
	 * @return Set<Item>: a set of items related to the search text is returned
	*/
  searchItems(branchId:number,searchText:string){
    return this.http.get<Item[]>("http://localhost:8094/customer/searchItems/"+branchId+"/"+searchText);
  }



  /* Method:getABranchCategories
	 * Type: GetMapping
	 * Description: Called from customer home page to view all the existing categories of items in his location
	 * @param int: branchId
	 * @return List<Category>: a List of all the existing categories of items in the given branch
	 * @throws ResourceNotFoundException : It is raised when no data is found with the given request
	*/
  getABranchCategories(branchId:number){
    return this.http.get<SubCategory[]>("http://localhost:8094/customer/getABranchSubCategories/"+branchId);
  }



  /* Method: trackAnOrder
	 * Type: GetMapping
	 * Description: Called from customer account page to get the status of an order placed
	 * @param int: orderId
	 * @return List<Order>: a list Order object with that order Id from the user account
	 * @throws ResourceNotFoundException : It is raised when no data is found with the given request
	*/
  trackAnOrder(orderId:number){
    return this.http.get<Order[]>("http://localhost:8094/customer/trackAnOrder/"+orderId);
  }



  /* Method:getACarryBoxDetails
	 * Type: GetMapping
	 * Description: Called from customer carry box page to get a list of items present in one's carrybox and related info
	 * @param int: carryBoxId
	 * @return CarryBox: a object of a CarryBox of given Carry Box id
	*/
  getCarryBoxDetails(emailId:string){
    return this.http.get<CarryBox>("http://localhost:8094/customer/getACarryBoxDetails/"+emailId);
  }



  /* Method:getMyOrders
	 * Type: GetMapping
	 * Description: Called from customer account page to get a list of orders placed
	 * @param String: emailId
	 * @return List<Order>: a list of Order objects placed from the user account
	 * @throws ResourceNotFoundException : It is raised when no data is found with the given request
	*/
  getMyOrders(emailId:string){
    return this.http.get<Order[]>("http://localhost:8094/customer/getAnUserOrders/"+emailId);
  }  



  /* Method:getMyAddresses
	 * Type: GetMapping
	 * Description: Called from customer account page and place order page to get a list of addresses saved
	 * @param String: emailId
	 * @return List<Address>: a list of Address objects saved to a user account
	 * @throws ResourceNotFoundException : It is raised when no data is found with the given request	
	*/
  getMyAddresses(emailId:string){
    return this.http.get<Address[]>("http://localhost:8094/customer/getAnUserAddresses/"+emailId);
  }  
  


  /* Method:addAnItemToCarryBox
	 * Type: PostMapping
	 * Description: Called from items page to add a desired item to carry box before buying
	 * @param String:emailId
	 * @param int: itemId
	 * @return boolean: a boolean is returned to notify whether the item is added to carry box or not
	*/
  addItemToCarryBox(emailId:string, itemId:number){
    return this.http.post<boolean>("http://localhost:8094/customer/addAnItemToCarryBox/"+emailId,itemId);
  }



  /* Method:addANewAddress
	 * Type: PostMapping
	 * Description: Called from customer account page and place order page to add a new address to the list of addresses saved
	 * @param Address: address 
	 * @return boolean: a boolean is returned to notify whether the new address is added or not
	 * @throws ResourceNotFoundException : It is raised when no data is found with the given request
	*/
  addANewAddress(emailId:string, address:Address){
    return this.http.post<boolean>("http://localhost:8094/customer/addANewAddress/"+emailId,address);
  }



  /* Method:placeOrder
	 * Type: PostMapping
	 * Description: Called from customer placeOrder page to place a new order
	 * @param String: emailId
	 * @param int:branchId
	 * @param int:addressId
	 * @return int: orderId is returned
	*/
  placeOrder(emailId:string, branchId:number, addressId:number){
    return this.http.post<boolean>("http://localhost:8094/customer/placeANewOrder/"+emailId+"/"+branchId+"/"+addressId,"");
  }



  /* Method:updateItemInCarryBox
	 * Type: PutMapping
	 * Description: Called from Carry Box page to update the quantity of an item in carry box
	 * @param String:emailId
	 * @param int: itemId
	 * @param int: quantity
	 * @return boolean: a boolean is returned to notify whether an item in the carry box is updated or not
	*/
  updateItemInCarryBox(emailId:string, itemId:number,quantity:number){
    return this.http.put<boolean>("http://localhost:8094/customer/updateACarryBoxItem/"+emailId+"/"+itemId,quantity);
  }



  /* Method:deleteACarryBoxItem
	 * Type: DeleteMapping
	 * Description: Called from Carry Box page to delete a item from carry box when not needed
	 * @param String:emailId
	 * @param int: itemId
	 * @return boolean: a boolean is returned to notify whether the item is deleted from carry box or not
	*/	
  deleteACarryBoxItem(emailId:string,itemId:number){
    return this.http.delete<boolean>("http://localhost:8094/customer/deleteACarryBoxItem/"+emailId+"/"+itemId);
  }



  /* Method:clearCarryBox
	 * Type: DeleteMapping
	 * Description: Called from Carry Box page to delete all the items in carry box when not needed
	 * @param String:emailId
	 * @return boolean: a boolean is returned to notify whether the items are deleted from carry box or not
	*/	
  clearTheCarryBox(emailId:string){
    return this.http.delete<boolean>("http://localhost:8094/customer/clearACarryBox/"+emailId);
  }
}
